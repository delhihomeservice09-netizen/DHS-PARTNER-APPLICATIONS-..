package com.delhihomeservice.dhspartner;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class BookingAlertActivity extends Activity {

    String id;
    String phone;

    MediaPlayer mp;

    Handler h = new Handler(Looper.getMainLooper());

    Runnable ring;
    Runnable timeout;

    FirebaseFirestore db =
            FirebaseFirestore.getInstance();

    boolean finished = false;

    @Override
    public void onCreate(Bundle b) {

        super.onCreate(b);

        if (Build.VERSION.SDK_INT >= 27) {
            getWindow().setTurnScreenOn(true);
        }

        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        id = getIntent().getStringExtra("bookingId");
        phone = getIntent().getStringExtra("phone");

        LinearLayout l = new LinearLayout(this);

        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(28, 45, 28, 28);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Color.WHITE);

        TextView h1 = new TextView(this);

        h1.setText("🔔  NEW DHS BOOKING");
        h1.setTextSize(25);
        h1.setTextColor(Color.rgb(6, 27, 70));
        h1.setGravity(Gravity.CENTER);

        l.addView(h1);

        l.addView(
                t(
                        "Customer: " +
                        getIntent().getStringExtra("customer"),
                        20
                )
        );

        l.addView(
                t(
                        "Service: " +
                        getIntent().getStringExtra("service"),
                        18
                )
        );

        l.addView(
                t(
                        "Address: " +
                        getIntent().getStringExtra("address"),
                        16
                )
        );

        TextView timer = t(
                "⏱ Accept within 15 seconds",
                17
        );

        timer.setTextColor(Color.RED);

        l.addView(timer);

        Button a = new Button(this);
        a.setText("✓ ACCEPT BOOKING");

        Button r = new Button(this);
        r.setText("✕ REJECT");

        Button c = new Button(this);
        c.setText("📞 CALL CUSTOMER");

        l.addView(a);
        l.addView(r);
        l.addView(c);

        a.setOnClickListener(
                v -> update("ACCEPTED", true)
        );

        r.setOnClickListener(
                v -> update("REJECTED", false)
        );

        c.setOnClickListener(v -> {

            try {

                if (phone != null &&
                        !phone.trim().isEmpty()) {

                    startActivity(
                            new Intent(
                                    Intent.ACTION_DIAL,
                                    Uri.parse("tel:" + phone)
                            )
                    );
                }

            } catch (Exception ignored) {
            }
        });

        setContentView(l);

        startRing();

        startTimeout(timer);
    }

    TextView t(String s, int z) {

        TextView t = new TextView(this);

        t.setText(s);
        t.setTextSize(z);
        t.setTextColor(Color.DKGRAY);
        t.setPadding(10, 16, 10, 16);

        return t;
    }

    void startRing() {

        try {

            int soundId =
                    getResources().getIdentifier(
                            "dhs_booking_alert",
                            "raw",
                            getPackageName()
                    );

            if (soundId != 0) {

                mp = MediaPlayer.create(
                        this,
                        soundId
                );

                if (mp != null) {

                    mp.setLooping(true);
                    mp.setVolume(1, 1);
                    mp.start();
                }
            }

        } catch (Exception ignored) {
        }

        ring = () -> {

            if (finished) {
                return;
            }

            try {

                Vibrator v =
                        (Vibrator)
                        getSystemService(
                                VIBRATOR_SERVICE
                        );

                if (v != null) {

                    if (Build.VERSION.SDK_INT >= 26) {

                        v.vibrate(
                                VibrationEffect.createOneShot(
                                        700,
                                        VibrationEffect.DEFAULT_AMPLITUDE
                                )
                        );

                    } else {

                        v.vibrate(700);
                    }
                }

            } catch (Exception ignored) {
            }

            h.postDelayed(ring, 1300);
        };

        h.post(ring);
    }

    void startTimeout(TextView timer) {

        final int[] seconds = {15};

        timeout = new Runnable() {

            @Override
            public void run() {

                if (finished) {
                    return;
                }

                seconds[0]--;

                if (seconds[0] <= 0) {

                    stopRing();

                    finished = true;

                    Toast.makeText(
                            BookingAlertActivity.this,
                            "Booking offer expired",
                            Toast.LENGTH_SHORT
                    ).show();

                    finish();

                    return;
                }

                timer.setText(
                        "⏱ Accept within " +
                        seconds[0] +
                        " seconds"
                );

                h.postDelayed(
                        this,
                        1000
                );
            }
        };

        h.postDelayed(
                timeout,
                1000
        );
    }

    void stopRing() {

        if (ring != null) {

            h.removeCallbacks(ring);
            ring = null;
        }

        if (timeout != null) {

            h.removeCallbacks(timeout);
            timeout = null;
        }

        if (mp != null) {

            try {

                if (mp.isPlaying()) {
                    mp.stop();
                }

            } catch (Exception ignored) {
            }

            try {
                mp.release();
            } catch (Exception ignored) {
            }

            mp = null;
        }

        try {

            Vibrator v =
                    (Vibrator)
                    getSystemService(
                            VIBRATOR_SERVICE
                    );

            if (v != null) {
                v.cancel();
            }

        } catch (Exception ignored) {
        }
    }

    void update(
            String status,
            boolean accept
    ) {

        if (finished) {
            return;
        }

        finished = true;

        stopRing();

        FirebaseUser currentUser =
                FirebaseAuth
                        .getInstance()
                        .getCurrentUser();

        String uid =
                currentUser == null
                        ? ""
                        : currentUser.getUid();

        if (uid.isEmpty()) {

            finished = false;

            Toast.makeText(
                    this,
                    "Partner login session not found.",
                    Toast.LENGTH_LONG
            ).show();

            startRing();

            return;
        }

        if (id == null ||
                id.trim().isEmpty()) {

            finished = false;

            Toast.makeText(
                    this,
                    "Booking ID not found.",
                    Toast.LENGTH_LONG
            ).show();

            startRing();

            return;
        }

        /*
         * REJECT
         *
         * Note:
         * This keeps your current business logic.
         */
        if (!accept) {

            db.collection("bookings")
                    .document(id)
                    .set(
                            Collections.singletonMap(
                                    "status",
                                    "REJECTED"
                            ),
                            SetOptions.merge()
                    )
                    .addOnSuccessListener(x -> {

                        finish();

                    })
                    .addOnFailureListener(x -> {

                        finished = false;

                        Toast.makeText(
                                this,
                                x.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();

                        startRing();
                    });

            return;
        }

        /*
         * ACCEPT
         *
         * Transaction ensures that two partners
         * cannot successfully claim the same booking
         * at the same time.
         */

        DocumentReference ref =
                db.collection("bookings")
                        .document(id);

        db.runTransaction(transaction -> {

            DocumentSnapshot snap =
                    transaction.get(ref);

            String currentStatus =
                    snap.getString("status");

            String existingPartner =
                    snap.getString("partnerUid");

            if (existingPartner != null &&
                    !existingPartner.trim().isEmpty()) {

                throw new IllegalStateException(
                        "Booking already accepted by another partner."
                );
            }

            if (currentStatus == null ||
                    (!"NEW".equalsIgnoreCase(
                            currentStatus
                    ) &&
                    !"PENDING_ACCEPT".equalsIgnoreCase(
                            currentStatus
                    ))) {

                throw new IllegalStateException(
                        "Booking is no longer available."
                );
            }

            Map<String, Object> m =
                    new HashMap<>();

            m.put(
                    "status",
                    "ACCEPTED"
            );

            m.put(
                    "partnerUid",
                    uid
            );

            m.put(
                    "workeruid",
                    uid
            );

            m.put(
                    "acceptedBy",
                    uid
            );

            m.put(
                    "acceptedAt",
                    FieldValue.serverTimestamp()
            );

            transaction.set(
                    ref,
                    m,
                    SetOptions.merge()
            );

            return null;

        }).addOnSuccessListener(x -> {

            Intent r =
                    new Intent(
                            this,
                            RouteActivity.class
                    );

            r.putExtra(
                    "bookingId",
                    id
            );

            r.putExtra(
                    "address",
                    getIntent().getStringExtra(
                            "address"
                    )
            );

            r.putExtra(
                    "customer",
                    getIntent().getStringExtra(
                            "customer"
                    )
            );

            r.putExtra(
                    "phone",
                    phone
            );

            startActivity(r);

            finish();

        }).addOnFailureListener(x -> {

            finished = false;

            Toast.makeText(
                    this,
                    x.getMessage(),
                    Toast.LENGTH_LONG
            ).show();

            finish();
        });
    }

    @Override
    public void onBackPressed() {

        stopRing();

        finished = true;

        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {

        stopRing();

        super.onDestroy();
    }
}