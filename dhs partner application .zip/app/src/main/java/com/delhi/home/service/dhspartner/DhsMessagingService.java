package com.delhihomeservice.dhspartner;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Collections;
import java.util.Map;

public class DhsMessagingService extends FirebaseMessagingService {

    private static final String CHANNEL_ID = "dhs_booking_alert_v2";
    private static final int NOTIFICATION_ID = 8208;

    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);

        if (FirebaseAuth.getInstance().getCurrentUser() != null) {

            String uid = FirebaseAuth.getInstance()
                    .getCurrentUser()
                    .getUid();

            FirebaseFirestore.getInstance()
                    .collection("workers")
                    .document(uid)
                    .set(
                            Collections.singletonMap("fcmToken", token),
                            SetOptions.merge()
                    );
        }
    }

    @Override
    public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);

        Map<String, String> data = message.getData();

        String bookingId = data.get("bookingId");

        showNotification(
                bookingId,
                data.get("service"),
                data.get("customer"),
                data.get("address"),
                data.get("phone")
        );
    }

    private void showNotification(
            String bookingId,
            String service,
            String customer,
            String address,
            String phone
    ) {

        createNotificationChannel();

        Intent intent = new Intent(
                this,
                BookingAlertActivity.class
        );

        if (bookingId != null && !bookingId.trim().isEmpty()) {
            intent.putExtra("bookingId", bookingId);
        }

        if (service != null) {
            intent.putExtra("service", service);
        }

        if (customer != null) {
            intent.putExtra("customer", customer);
        }

        if (address != null) {
            intent.putExtra("address", address);
        }

        if (phone != null) {
            intent.putExtra("phone", phone);
        }

        intent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_SINGLE_TOP
        );

        int requestCode;

        if (bookingId == null || bookingId.trim().isEmpty()) {
            requestCode = NOTIFICATION_ID;
        } else {
            requestCode = Math.abs(bookingId.hashCode());
        }

        PendingIntent pendingIntent =
                PendingIntent.getActivity(
                        this,
                        requestCode,
                        intent,
                        PendingIntent.FLAG_UPDATE_CURRENT |
                        PendingIntent.FLAG_IMMUTABLE
                );

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(
                        this,
                        CHANNEL_ID
                )
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(
                        "🔔 DHS Partner — New Booking"
                )
                .setContentText(
                        service == null
                                ? "New booking received"
                                : service
                )
                .setPriority(
                        NotificationCompat.PRIORITY_MAX
                )
                .setCategory(
                        NotificationCompat.CATEGORY_CALL
                )
                .setVisibility(
                        NotificationCompat.VISIBILITY_PUBLIC
                )
                .setAutoCancel(false)
                .setOngoing(true)
                .setVibrate(
                        new long[]{
                                0,
                                700,
                                600,
                                700
                        }
                )
                .setContentIntent(pendingIntent)
                .setFullScreenIntent(
                        pendingIntent,
                        true
                );

        NotificationManager manager =
                getSystemService(
                        NotificationManager.class
                );

        if (manager != null) {
            manager.notify(
                    requestCode,
                    builder.build()
            );
        }
    }

    private void createNotificationChannel() {

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return;
        }

        NotificationManager manager =
                getSystemService(
                        NotificationManager.class
                );

        if (manager == null) {
            return;
        }

        Uri soundUri = Uri.parse(
                "android.resource://" +
                getPackageName() +
                "/" +
                R.raw.dhs_booking_alert
        );

        AudioAttributes audioAttributes =
                new AudioAttributes.Builder()
                        .setUsage(
                                AudioAttributes.USAGE_ALARM
                        )
                        .setContentType(
                                AudioAttributes.CONTENT_TYPE_SONIFICATION
                        )
                        .build();

        NotificationChannel channel =
                new NotificationChannel(
                        CHANNEL_ID,
                        "DHS Booking Alerts",
                        NotificationManager.IMPORTANCE_HIGH
                );

        channel.setDescription(
                "Urgent notifications for new DHS Partner bookings"
        );

        channel.setSound(
                soundUri,
                audioAttributes
        );

        channel.enableVibration(true);

        channel.setVibrationPattern(
                new long[]{
                        0,
                        700,
                        600,
                        700
                }
        );

        channel.setLockscreenVisibility(
                android.app.Notification.VISIBILITY_PUBLIC
        );

        manager.createNotificationChannel(channel);
    }
}